export declare function setUrlParams(params: Record<string, string | number | null>): void;
export declare function getUrlParams(): Record<string, string>;
//# sourceMappingURL=url-params.d.ts.map