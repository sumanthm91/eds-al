export declare function toDateString(value: string, locale?: string): string;
export declare function isDateValid(dateString: string): boolean;
//# sourceMappingURL=date.d.ts.map