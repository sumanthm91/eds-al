import { ProductModel } from '../../data/models';

export declare const getRefinedProduct: (sku: string, optionUIDs: string[], anchorOptions?: string[]) => Promise<ProductModel | null>;
//# sourceMappingURL=getRefinedProduct.d.ts.map