export declare const REFINE_PRODUCT_QUERY: string;
//# sourceMappingURL=RefineProductQuery.graphql.d.ts.map