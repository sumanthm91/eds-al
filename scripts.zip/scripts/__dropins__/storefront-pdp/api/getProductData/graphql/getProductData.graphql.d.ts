export declare const GET_PRODUCT_DATA: string;
//# sourceMappingURL=getProductData.graphql.d.ts.map