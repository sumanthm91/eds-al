import { ProductModel } from '../../data/models';

export declare const getProductData: (sku: string) => Promise<ProductModel | null>;
//# sourceMappingURL=getProductData.d.ts.map