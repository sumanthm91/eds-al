export * from './getProductData';
//# sourceMappingURL=index.d.ts.map