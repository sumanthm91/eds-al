export declare const ProductFragment: string;
//# sourceMappingURL=ProductFragment.graphql.d.ts.map