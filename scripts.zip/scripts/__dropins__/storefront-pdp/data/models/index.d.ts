export * from './product-model';
//# sourceMappingURL=index.d.ts.map