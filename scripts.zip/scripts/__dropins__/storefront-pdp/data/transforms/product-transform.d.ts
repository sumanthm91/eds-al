import { ProductModel } from '../models';

export declare function transformProductData(data: any): ProductModel | null;
//# sourceMappingURL=product-transform.d.ts.map