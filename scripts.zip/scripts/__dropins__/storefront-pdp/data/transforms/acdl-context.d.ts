import { ProductModel } from '../models';
import { Product } from '../models/acdl-models';

export declare function transformProduct(product: ProductModel): Product;
//# sourceMappingURL=acdl-context.d.ts.map