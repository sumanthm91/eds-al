export * from './ProductDetails';
export { ProductDetails as default } from './ProductDetails';
//# sourceMappingURL=index.d.ts.map