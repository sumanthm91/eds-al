export * from './ProductDetails/index'
import _default from './ProductDetails/index'
export default _default
