export * from './ProductDetails';
//# sourceMappingURL=index.d.ts.map