export * from './render';
//# sourceMappingURL=index.d.ts.map