import { FunctionComponent } from 'preact';

interface CartProviderProps {
    children?: any;
}
export declare const Provider: FunctionComponent<CartProviderProps>;
export {};
//# sourceMappingURL=Provider.d.ts.map