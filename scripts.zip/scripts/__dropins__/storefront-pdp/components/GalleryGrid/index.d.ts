export * from './GalleryGrid';
export { GalleryGrid as default } from './GalleryGrid';
//# sourceMappingURL=index.d.ts.map