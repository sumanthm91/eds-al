export * from './Swatches';
export { Swatches as default } from './Swatches';
//# sourceMappingURL=index.d.ts.map