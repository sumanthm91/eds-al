export * from './Product';
export { Product as default } from './Product';
//# sourceMappingURL=index.d.ts.map