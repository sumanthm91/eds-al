export * from './Carousel';
export { Carousel as default } from './Carousel';
//# sourceMappingURL=index.d.ts.map