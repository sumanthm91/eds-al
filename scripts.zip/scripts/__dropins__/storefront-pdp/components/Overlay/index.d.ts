export * from './Overlay';
export { Overlay as default } from './Overlay';
//# sourceMappingURL=index.d.ts.map