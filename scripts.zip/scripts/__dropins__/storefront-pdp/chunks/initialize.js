import{Initializer as t}from"@dropins/tools/lib.js";const i=new t({init:async n=>{const o={defaultLocale:"en-US"};i.config.setConfig({...o,...n})},listeners:()=>[]}),c=i.config;export{c,i};
