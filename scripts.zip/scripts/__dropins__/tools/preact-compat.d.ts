export * from 'preact/compat'
