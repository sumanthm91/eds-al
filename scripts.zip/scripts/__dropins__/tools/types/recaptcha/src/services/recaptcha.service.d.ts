export declare const getRecaptchaToken: (websiteKey: string) => Promise<string>;
export declare const waitForReCaptcha: () => Promise<unknown>;
export declare const verifyReCaptchaLoad: (badgeId: string, config: any) => Promise<void>;
//# sourceMappingURL=recaptcha.service.d.ts.map