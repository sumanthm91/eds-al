export * from './_extendConfig';
export * from './_storageConfig';
//# sourceMappingURL=index.d.ts.map