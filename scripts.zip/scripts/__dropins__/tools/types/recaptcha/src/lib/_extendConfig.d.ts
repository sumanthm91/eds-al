import { ReCaptchaV3Props, ReCaptchaV3ModifyProps } from '../types/recaptcha.types';

export declare const extendConfig: (config: ReCaptchaV3Props | ReCaptchaV3ModifyProps, modifyParams: any[]) => ReCaptchaV3ModifyProps;
//# sourceMappingURL=_extendConfig.d.ts.map