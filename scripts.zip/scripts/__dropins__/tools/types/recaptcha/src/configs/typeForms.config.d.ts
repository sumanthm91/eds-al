export declare const typeDefaultForm: Record<string, string>;
//# sourceMappingURL=typeForms.config.d.ts.map