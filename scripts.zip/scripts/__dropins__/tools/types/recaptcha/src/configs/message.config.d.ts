export declare const recaptchaMessage: {
    failedFetch: string;
    failedSetStorageConfig: string;
    failedGetStorageConfig: string;
    failedExecutionRecaptcha: string;
    failedInitializing: string;
};
//# sourceMappingURL=message.config.d.ts.map