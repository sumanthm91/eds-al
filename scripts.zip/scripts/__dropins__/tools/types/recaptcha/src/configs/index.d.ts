export * from './message.config';
export * from './typeForms.config';
//# sourceMappingURL=index.d.ts.map