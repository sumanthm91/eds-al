export declare const setImageParamsKeyMap: (value: typeof this._map) => void, getImageParamsKeyMap: () => {
    [key: string]: string;
} | undefined;
//# sourceMappingURL=image-params-keymap.d.ts.map