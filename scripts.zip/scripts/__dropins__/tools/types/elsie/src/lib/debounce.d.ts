export declare const debounce: (fn: Function, ms: number) => (this: any, ...args: any[]) => void;
//# sourceMappingURL=debounce.d.ts.map