export declare const getFormValues: (form: HTMLFormElement) => {
    [k: string]: any;
};
export declare const getFormErrors: (form: HTMLFormElement) => {};
//# sourceMappingURL=form-values.d.ts.map