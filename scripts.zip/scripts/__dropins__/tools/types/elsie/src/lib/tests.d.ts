import { RenderOptions, RenderResult } from '@testing-library/preact';

export * from '@testing-library/preact';
export declare const render: (ui: any, options?: Omit<RenderOptions, 'queries'>) => RenderResult;
//# sourceMappingURL=tests.d.ts.map