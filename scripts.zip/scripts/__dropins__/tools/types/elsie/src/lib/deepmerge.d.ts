export { default as deepmerge } from 'deepmerge';
//# sourceMappingURL=deepmerge.d.ts.map