export * from './TextSwatch';
export { TextSwatch as default } from './TextSwatch';
//# sourceMappingURL=index.d.ts.map