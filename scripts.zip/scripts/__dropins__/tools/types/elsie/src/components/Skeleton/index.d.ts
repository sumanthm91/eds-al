export * from './Skeleton';
//# sourceMappingURL=index.d.ts.map