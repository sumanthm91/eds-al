export * from './InputPassword';
export { InputPassword as default } from './InputPassword';
//# sourceMappingURL=index.d.ts.map