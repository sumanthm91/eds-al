export * from './IllustratedMessage';
export { IllustratedMessage as default } from './IllustratedMessage';
//# sourceMappingURL=index.d.ts.map