export * from './Icon';
//# sourceMappingURL=index.d.ts.map