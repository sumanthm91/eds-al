export * from './Divider';
export { Divider as default } from './Divider';
//# sourceMappingURL=index.d.ts.map