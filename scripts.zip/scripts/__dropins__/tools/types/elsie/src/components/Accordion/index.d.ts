export * from './Accordion';
export { Accordion as default } from './Accordion';
//# sourceMappingURL=index.d.ts.map