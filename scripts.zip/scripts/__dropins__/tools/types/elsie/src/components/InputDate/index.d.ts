export * from './InputDate';
export { InputDate as default } from './InputDate';
//# sourceMappingURL=index.d.ts.map