export * from './Input';
export { Input as default } from '.';
//# sourceMappingURL=index.d.ts.map