export * from './Button';
export { Button as default } from './Button';
//# sourceMappingURL=index.d.ts.map