export * from './ImageSwatch';
export { ImageSwatch as default } from './ImageSwatch';
//# sourceMappingURL=index.d.ts.map