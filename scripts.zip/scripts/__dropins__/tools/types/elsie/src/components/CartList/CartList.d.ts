import { FunctionComponent } from 'preact';
import { HTMLAttributes } from 'preact/compat';

export interface CartListProps extends HTMLAttributes<HTMLDivElement> {
}
export declare const CartList: FunctionComponent<CartListProps>;
//# sourceMappingURL=CartList.d.ts.map