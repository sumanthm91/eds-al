import { FunctionComponent } from 'preact';

export declare const CartItemSkeleton: FunctionComponent;
//# sourceMappingURL=CartItemSkeleton.d.ts.map