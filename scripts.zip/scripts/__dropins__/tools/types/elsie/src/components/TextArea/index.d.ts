export * from './TextArea';
export { TextArea as default } from './TextArea';
//# sourceMappingURL=index.d.ts.map