export * from './Incrementer';
//# sourceMappingURL=index.d.ts.map