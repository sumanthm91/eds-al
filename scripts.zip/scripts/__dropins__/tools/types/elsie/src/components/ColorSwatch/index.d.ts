export * from './ColorSwatch';
export { ColorSwatch as default } from './ColorSwatch';
//# sourceMappingURL=index.d.ts.map